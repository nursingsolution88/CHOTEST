Nursing Solution Project Skeleton
Configure Google Apps Script URL and expand features as needed.